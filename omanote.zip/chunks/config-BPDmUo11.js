const t="https://omanote.iambishistha.com";function o(){return t}function e(){return"https://intent-clownfish-356.convex.cloud"}export{e as a,o as g};
