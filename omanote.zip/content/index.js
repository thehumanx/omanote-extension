const L=`
  :host {
    all: initial;
    position: fixed;
    z-index: 2147483647;
    pointer-events: none;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }

  * {
    box-sizing: border-box;
  }

  .bubble {
    pointer-events: all;
    position: fixed;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px 6px 8px;
    background: #ffffff;
    border: 1px solid #e4e4e7;
    border-radius: 20px;
    cursor: pointer;
    box-shadow: 0 4px 16px rgba(0,0,0,0.1), 0 1px 4px rgba(0,0,0,0.06);
    transition: transform 0.1s ease, box-shadow 0.1s ease, opacity 0.15s ease;
    opacity: 0;
    transform: translateY(4px) scale(0.96);
    user-select: none;
    white-space: nowrap;
  }

  .bubble.visible {
    opacity: 1;
    transform: translateY(0) scale(1);
  }

  .bubble:hover {
    background: #f4f4f5;
    box-shadow: 0 6px 20px rgba(0,0,0,0.12);
  }

  .bubble:active {
    transform: scale(0.97);
  }

  .bubble-logo {
    width: 76px;
    height: 19px;
    display: block;
    object-fit: contain;
    flex-shrink: 0;
  }

  .bubble-label {
    font-size: 12px;
    font-weight: 600;
    color: #18181b;
    line-height: 1;
  }

  /* Save Modal */
  .modal-overlay {
    pointer-events: none;
    position: fixed;
    inset: 0;
    z-index: 2147483646;
    background: rgba(0,0,0,0.35);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.15s ease;
  }

  .modal-overlay.visible {
    pointer-events: all;
    opacity: 1;
  }

  .modal {
    background: #ffffff;
    border: 1px solid #e4e4e7;
    border-radius: 12px;
    width: 360px;
    max-width: calc(100vw - 32px);
    max-height: calc(100vh - 64px);
    overflow-y: auto;
    box-shadow: 0 24px 64px rgba(0,0,0,0.15);
    transform: translateY(8px) scale(0.98);
    transition: transform 0.15s ease;
  }

  .modal-overlay.visible .modal {
    transform: translateY(0) scale(1);
  }

  .modal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 16px 0;
  }

  .modal-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    font-weight: 700;
    color: #18181b;
  }

  .modal-title-logo {
    width: 98px;
    height: 25px;
    display: block;
    object-fit: contain;
  }

  .modal-close {
    background: none;
    border: none;
    cursor: pointer;
    color: #71717a;
    font-size: 18px;
    line-height: 1;
    padding: 2px 4px;
    border-radius: 4px;
    transition: color 0.1s, background 0.1s;
  }

  .modal-close:hover {
    color: #18181b;
    background: #f4f4f5;
  }

  .type-tabs {
    display: flex;
    gap: 4px;
    padding: 12px 16px 0;
  }

  .type-tab {
    padding: 5px 12px;
    border-radius: 20px;
    border: 1px solid #e4e4e7;
    background: none;
    color: #71717a;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.1s;
  }

  .type-tab:hover {
    color: #18181b;
    border-color: #d4d4d8;
    background: #f4f4f5;
  }

  .type-tab.active {
    background: #18181b;
    border-color: #18181b;
    color: #fff;
  }

  .modal-body {
    padding: 12px 16px;
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .field-label {
    font-size: 10px;
    font-weight: 700;
    color: #71717a;
    margin-bottom: 4px;
    display: block;
    text-transform: uppercase;
    letter-spacing: 0.06em;
  }

  .field-textarea {
    width: 100%;
    background: #fafafa;
    border: 1px solid #e4e4e7;
    border-radius: 6px;
    color: #18181b;
    font-size: 13px;
    line-height: 1.55;
    padding: 7px 9px;
    resize: none;
    outline: none;
    font-family: inherit;
    min-height: 80px;
    transition: border-color 0.15s;
  }

  .field-textarea::placeholder {
    color: #a1a1aa;
  }

  .field-textarea:focus {
    border-color: #5a8b16;
    background: #fff;
  }

  .field-input {
    width: 100%;
    background: #fafafa;
    border: 1px solid #e4e4e7;
    border-radius: 6px;
    color: #18181b;
    font-size: 13px;
    padding: 7px 9px;
    outline: none;
    font-family: inherit;
    transition: border-color 0.15s;
  }

  .field-input::placeholder {
    color: #a1a1aa;
  }

  .field-input:focus {
    border-color: #5a8b16;
    background: #fff;
  }

  .field-select {
    width: 100%;
    background: #fafafa;
    border: 1px solid #e4e4e7;
    border-radius: 6px;
    color: #18181b;
    font-size: 13px;
    padding: 7px 9px;
    outline: none;
    font-family: inherit;
    cursor: pointer;
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='11' height='11' viewBox='0 0 24 24' fill='none' stroke='%23a1a1aa' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 9px center;
    padding-right: 26px;
    transition: border-color 0.15s;
  }

  .field-select:focus {
    border-color: #5a8b16;
    background-color: #fff;
  }

  .source-url {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    color: #71717a;
    padding: 3px 0;
    cursor: pointer;
    user-select: none;
  }

  .source-url input[type="checkbox"] {
    accent-color: #5a8b16;
    width: 13px;
    height: 13px;
    cursor: pointer;
  }

  .source-url-text {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    max-width: 280px;
  }

  .modal-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 16px 14px;
    gap: 8px;
  }

  .btn-cancel {
    background: #f4f4f5;
    border: 1px solid #e4e4e7;
    border-radius: 6px;
    color: #71717a;
    font-size: 13px;
    font-weight: 600;
    padding: 8px 16px;
    cursor: pointer;
    font-family: inherit;
    transition: color 0.1s, border-color 0.1s;
  }

  .btn-cancel:hover {
    color: #18181b;
    border-color: #d4d4d8;
  }

  .btn-save {
    background: #18181b;
    border: none;
    border-radius: 6px;
    color: #fff;
    font-size: 13px;
    font-weight: 700;
    padding: 8px 20px;
    cursor: pointer;
    font-family: inherit;
    display: flex;
    align-items: center;
    gap: 6px;
    flex: 1;
    justify-content: center;
    transition: background 0.1s;
    letter-spacing: 0.01em;
  }

  .btn-save:hover {
    background: #27272a;
  }

  .btn-save:disabled {
    background: #e4e4e7;
    color: #71717a;
    cursor: not-allowed;
  }

  .btn-save .shortcut-hint {
    font-size: 10px;
    opacity: 0.55;
    font-weight: 400;
  }

  .status-success {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 8px;
    padding: 24px 16px;
    color: #059669;
    font-size: 14px;
    font-weight: 700;
  }

  .status-success-icon {
    font-size: 32px;
  }

  .status-error {
    font-size: 12px;
    color: #ef4444;
    padding: 4px 0 6px;
  }
`;let f=null,g=null,c=null,i=null,n=null,m=null;function k(e){return chrome.runtime.sendMessage(e)}function T(e,t){const l=t.trim().replace(/\)/g,"\\)");return`${e.trim()}

[Source](${l})`.trim()}function w(){if(f)return;f=document.createElement("div"),f.id="omanote-ext-root",document.body.appendChild(f),g=f.attachShadow({mode:"closed"});const e=document.createElement("style");e.textContent=L,g.appendChild(e)}function S(){if(!c){const e=chrome.runtime.getURL("assets/logo.svg");c=document.createElement("div"),c.className="bubble",c.innerHTML=`
      <img class="bubble-logo" src="${e}" alt="omanote" />
      <span class="bubble-label">Save</span>
    `,c.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation(),$()}),g.appendChild(c)}return c}function _(e){const t=S(),l=8;let o=e.top-44+window.scrollY,a=e.left+window.scrollX;o<8&&(o=e.bottom+l+window.scrollY),a+180>window.innerWidth-8&&(a=window.innerWidth-188),a<8&&(a=8),t.style.top=`${o}px`,t.style.left=`${a}px`}function z(e){w();const t=S();_(e),requestAnimationFrame(()=>{t.classList.add("visible")})}function h(){c&&c.classList.remove("visible")}function M(e){const t=chrome.runtime.getURL("assets/logo.svg"),l=e.folders.map(r=>`<option value="${r._id}" ${e.folderId===r._id?"selected":""}>${r.name}</option>`).join(""),o=e.categories.map(r=>`<option value="${r._id}" ${e.categoryId===r._id?"selected":""}>${r.name}</option>`).join("");if(e.saved)return`
      <div class="modal-header">
        <div class="modal-title"><img class="modal-title-logo" src="${t}" alt="omanote" /></div>
      </div>
      <div class="status-success">
        <div class="status-success-icon">✓</div>
        <span>Saved successfully!</span>
      </div>
    `;const a=e.type==="note",d=e.type==="bookmark",p=e.type==="todo";return`
    <div class="modal-header">
      <div class="modal-title"><img class="modal-title-logo" src="${t}" alt="omanote" /><span>Save</span></div>
      <button class="modal-close" data-action="close">×</button>
    </div>

    <div class="type-tabs">
      <button class="type-tab ${a?"active":""}" data-type="note">Note</button>
      <button class="type-tab ${d?"active":""}" data-type="bookmark">Bookmark</button>
      <button class="type-tab ${p?"active":""}" data-type="todo">Todo</button>
    </div>

    <div class="modal-body">
      ${a||p?`
        <div>
          <label class="field-label">${p?"Task":"Content"}</label>
          <textarea class="field-textarea" data-field="content" rows="${p?2:4}">${u(e.content)}</textarea>
        </div>
      `:""}

      ${d?`
        <div>
          <label class="field-label">URL</label>
          <input class="field-input" data-field="url" type="url" value="${u(e.url)}" />
        </div>
      `:""}

      ${a?`
        <div>
          <label class="field-label">Folder</label>
          <select class="field-select" data-field="folderId">
            <option value="">No folder</option>
            ${l}
          </select>
        </div>
      `:""}

      ${d?`
        <div>
          <label class="field-label">Category</label>
          <select class="field-select" data-field="categoryId">
            <option value="">Inbox</option>
            ${o}
          </select>
        </div>
      `:""}

      ${a||d?`
        <div>
          <label class="field-label">Hashtags</label>
          <input class="field-input" data-field="hashtags" type="text" placeholder="#tag1 #tag2" value="${u(e.hashtags)}" />
        </div>
      `:""}

      ${(a||p)&&e.url?`
        <label class="source-url">
          <input type="checkbox" data-field="includeUrl" ${e.includeUrl?"checked":""} />
          <span class="source-url-text" title="${u(e.url)}">${u(e.url)}</span>
        </label>
      `:""}

      ${e.error?`<div class="status-error">${u(e.error)}</div>`:""}
    </div>

    <div class="modal-footer">
      <button class="btn-cancel" data-action="close">Cancel</button>
      <button class="btn-save" data-action="save" ${e.saving?"disabled":""}>
        ${e.saving?"Saving…":"Save"}
        ${e.saving?"":'<span class="shortcut-hint">⌘↩</span>'}
      </button>
    </div>
  `}function u(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function b(){if(!i||!n)return;const e=i.querySelector(".modal");e&&(e.innerHTML=M(n),U(i,e))}function U(e,t){if(!n)return;t.querySelectorAll("[data-action='close']").forEach(o=>{o.addEventListener("click",x)}),t.querySelectorAll(".type-tab").forEach(o=>{o.addEventListener("click",()=>{const a=o.dataset.type;n&&(n={...n,type:a,error:""},b())})}),t.querySelectorAll("[data-field]").forEach(o=>{const a=o.dataset.field;o.addEventListener("input",()=>{n&&(o.type==="checkbox"?n[a]=o.checked:n[a]=o.value)}),o.addEventListener("change",()=>{n&&(o.type==="checkbox"?n[a]=o.checked:n[a]=o.value)})});const l=t.querySelector("[data-action='save']");l&&l.addEventListener("click",()=>void E()),e.addEventListener("click",o=>{o.target===e&&x()})}async function E(){if(!n||n.saving)return;n={...n,saving:!0,error:""},b();const e=n,t=e.hashtags.split(/[\s,]+/).map(d=>d.replace(/^#/,"").trim()).filter(Boolean);let l=e.content;(e.type==="note"||e.type==="todo")&&e.includeUrl&&e.url&&(l=T(l,e.url));const o={type:e.type,content:l,url:e.type==="bookmark"?e.url:e.url||void 0,pageTitle:e.pageTitle,folderId:e.folderId||void 0,categoryId:e.categoryId||void 0,hashtags:t},a=await k({type:"SAVE_ITEM",payload:o});n&&(a.type==="SAVE_SUCCESS"?(n={...n,saving:!1,saved:!0},b(),setTimeout(x,1500)):a.type==="SAVE_ERROR"&&(n={...n,saving:!1,error:a.error},b()))}async function B(){try{const e=await k({type:"GET_FOLDERS"});if(e.type!=="FOLDERS_RESPONSE"||!n)return;n={...n,folders:e.data.folders,categories:e.data.categories},b()}catch{}}function $(e){w(),h();const t=window.getSelection(),l=(t==null?void 0:t.toString().trim())??"",o=window.location.href,a=document.title;let d="note",p=l,r="";if(e!=null&&e.type?(d=e.type,p=e.content??l,r=e.url??o):/^https?:\/\//i.test(l)?(d="bookmark",r=l):r=o,n={type:d,content:p,url:r,pageTitle:(e==null?void 0:e.pageTitle)??a,folderId:"",categoryId:"",hashtags:"",includeUrl:!!r,folders:[],categories:[],saving:!1,saved:!1,error:""},!i){i=document.createElement("div"),i.className="modal-overlay";const s=document.createElement("div");s.className="modal",i.appendChild(s),g.appendChild(i)}b();const v=s=>{(s.metaKey||s.ctrlKey)&&s.key==="Enter"&&(s.preventDefault(),E()),s.key==="Escape"&&x()};i.addEventListener("keydown",v),i._keyHandler=v,requestAnimationFrame(()=>{i.classList.add("visible");const s=i.querySelector("textarea, input");s==null||s.focus()}),B()}function x(){if(!i)return;i.classList.remove("visible");const e=i;e._keyHandler&&(e.removeEventListener("keydown",e._keyHandler),delete e._keyHandler),setTimeout(()=>{n=null},150)}function I(){let e="";document.addEventListener("selectionchange",()=>{m&&clearTimeout(m);const t=window.getSelection(),l=(t==null?void 0:t.toString().trim())??"";if(!l||l===e){l||h();return}e=l,m=setTimeout(()=>{const o=t==null?void 0:t.getRangeAt(0);if(!o)return;const a=o.getBoundingClientRect();a.width===0&&a.height===0||z(a)},200)}),document.addEventListener("mousedown",t=>{var l;f&&((l=t.target)==null?void 0:l.getRootNode())===g||h()})}function R(e){$({type:e._defaultType,content:e._content??e.context.selectedText,url:e.context.selectedUrl??e.context.pageUrl,pageTitle:e.context.pageTitle})}const y=globalThis;y.__omanoteContentScriptLoaded||(y.__omanoteContentScriptLoaded=!0,I(),chrome.runtime.onMessage.addListener(e=>{e.type==="OPEN_SAVE_MODAL"&&R({_defaultType:e._defaultType,_content:e._content,context:e.context})}));
